# Ink Duel

A stickman fighting game: 20 original fighters, each with a unique special and finisher,
four CPU difficulties (Easy, Normal, Hard, Nightmare) and a practice mode.

## Play
Open `index.html` in any modern browser. No install or build step.
An internet connection loads the fonts; the game still works offline with fallback fonts.

## Controls
- Move: A / D or arrow keys
- Jump: W · Crouch: S
- Punch: J · Kick: K
- Block: hold L · Special: I
- Pause: Esc or P
- Phones and tablets get on-screen controls automatically. Landscape gives the biggest stage; portrait uses a closer, following camera. Tap the full-screen button next to pause for edge-to-edge play.

Combos: Punch x3 · Crouch + Punch = uppercut · Crouch + Kick = sweep · Kick in the air = flying kick.

## Host it
Upload the folder to Vercel, Netlify, GitHub Pages or any static host. `index.html` is the whole game.
